import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
test('home display remains capped at 700px and keypad is materially smaller', () => {
 const css=read('assets/css/app.css');
 assert.match(css,/width:min\(100%,700px\)!important/);
 assert.match(css,/width:64%!important; height:64%!important/);
 assert.match(css,/max-height:64px!important/);
});
test('currency and unit picker initially exposes selected row only and alternatives require a query',()=>{
 const js=read('assets/js/app.js');
 assert.match(js,/const revealAlternatives = searchable && query\.length > 0/);
 assert.match(js,/if \(searchable && !revealAlternatives && index !== selectedIndex\) return/);
 assert.match(js,/searchInput\.blur\(\)/);
});
test('hidden native selectors and stale hidden labels cannot paint over picker UI',()=>{
 const css=read('assets/css/app.css');
 assert.match(css,/\.sumaire-picker-backdrop \[hidden\]/);
 assert.match(css,/select\.sumaire-select-native/);
 assert.match(css,/#screen-currencies \.currency-select-wrap > \.currency-name\[hidden\]/);
});
