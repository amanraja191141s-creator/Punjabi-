import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
test('v98.60 charcoal/violet visual layer is loaded after the previous design layers', () => {
  const builder = read('scripts/prepare-android-web.mjs');
  const html = read('index.html');
  const css = read('assets/css/app.css');
  assert.match(builder,/assets\/css\/app\.css/);
  assert.match(html,/assets\/css\/app\.css/);
  assert.match(css, /--theme-accent:#8b78ff/);
  assert.match(css, /#screen-calc/);
  assert.match(css, /#screen-scientific/);
  assert.match(css, /#screen-currencies/);
  assert.match(css, /#screen-units/);
  assert.match(css, /#history-modal/);
});
test('v98.60 provides twelve functioning palette choices and independent appearance modes', () => {
  const js = read('assets/js/app.js');
  const html = read('index.html');
  assert.match(js, /const THEME_PALETTE = \{/);
  assert.match(js, /function selectPaletteTheme\(name\)/);
  assert.match(js, /STATE\.accentColor = color/);
  assert.match(js, /function applySettingTheme\(val\)/);
  assert.match(html, /option value="system"/);
  assert.match(html, /option value="light"/);
  assert.match(html, /option value="dark"/);
});
test('v98.60 release identity and calculator-only scope are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  assert.equal(pkg.version, '1.98.64-v98.63.9');
  assert.equal(manifest.version, pkg.version);
  assert.match(read('service-worker.js'), /sa-calculator-v98-63-9-clean-runtime-v98639/);
  assert.doesNotMatch(read('index.html'), /private-vault|vault-pin|vault-unlock/i);
});
